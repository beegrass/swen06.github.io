var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1636053128256.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1636053128256-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1636053128256-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-7b2ed56c-0ff9-4871-9e7d-8481477f0e1b" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Feedback" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/7b2ed56c-0ff9-4871-9e7d-8481477f0e1b-1636053128256.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/7b2ed56c-0ff9-4871-9e7d-8481477f0e1b-1636053128256-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/7b2ed56c-0ff9-4871-9e7d-8481477f0e1b-1636053128256-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Paragraph_2" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="266.8" dataY="196.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="pie richtext autofit firer ie-background commentable non-processed" customid="Give us some feedback on "   datasizewidth="501.5px" datasizeheight="29.0px" dataX="27.0" dataY="81.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">Give us some feedback on our service here</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_2" class="pie textarea firer commentable non-processed" customid="Input_2"  datasizewidth="1226.0px" datasizeheight="188.0px" dataX="27.0" dataY="110.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><textarea   tabindex="-1" placeholder=""></textarea></div></div></div>\
      <div id="s-Paragraph_6" class="pie richtext autofit firer ie-background commentable non-processed" customid="Have a question? Type it "   datasizewidth="354.1px" datasizeheight="29.0px" dataX="27.0" dataY="334.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">Have a question? Type it here.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_3" class="pie textarea firer commentable non-processed" customid="Input_2"  datasizewidth="1226.0px" datasizeheight="188.0px" dataX="27.0" dataY="363.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><textarea   tabindex="-1" placeholder=""></textarea></div></div></div>\
\
      <div id="s-Image_17" class="pie image firer ie-background commentable non-processed" customid="Image_17"   datasizewidth="77.0px" datasizeheight="76.0px" dataX="82.4" dataY="631.9"   alt="image" systemName="./images/d14437f7-44df-47af-89d4-417750ca649b.svg" overlay="#CBCBCB">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="31px" version="1.1" viewBox="0 0 32 31" width="32px">\
          	    <!-- Generator: Sketch 55.1 (78136) - https://sketchapp.com -->\
          	    <title>Fill-1</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_17-Page-1" stroke="none" stroke-width="1">\
          	        <path d="M6.71966541,13.6057121 L6.71966541,28.2326439 L6.71316041,28.2326439 L6.71316041,28.2782671 L1.88645011,28.2782671 L1.88645011,13.6057121 L6.71966541,13.6057121 Z M19.8338113,12.1240973 L27.4511017,12.1240973 C28.0625067,12.1240973 28.6646745,12.3534539 29.1472155,12.7702641 C29.8749299,13.3951531 30.2278912,14.3879003 30.0683235,15.3611319 L28.3248533,26.2747585 L28.3175027,26.3132021 C28.2030797,27.2411368 27.8516796,27.9464377 27.273255,28.4093933 C26.689236,28.8767873 25.8561406,29.1137804 24.7970615,29.1137804 L11.2796707,29.1137804 C9.9756783,29.1137804 8.83938484,28.1376116 8.63701427,26.8454739 C8.63018402,26.7971093 8.61801967,26.750768 8.60611552,26.708604 L8.60611552,14.3555919 L8.80744528,14.3089896 C8.81707268,14.3077495 8.82546414,14.3059219 8.83248954,14.3040944 L8.86781169,14.2952178 C9.14577035,14.21337 10.6064031,13.7519808 12.0698331,12.7075403 C14.2382099,11.1639196 15.3843259,9.08887567 15.3843259,6.70673937 L15.3843259,1.93248054 C16.0132294,1.84612916 17.0481099,1.8196298 17.7987219,2.38016317 C18.5231838,2.91608999 18.8905862,3.94793351 18.8905862,5.44704047 L18.8905862,11.1776914 C18.8905862,11.6995201 19.3136714,12.1240973 19.8338113,12.1240973 Z M30.3731478,11.3340768 C29.5477283,10.627079 28.5100507,10.2378124 27.4511017,10.2378124 L20.7770363,10.2378124 L20.7770363,5.44704047 C20.7770363,3.31005593 20.1483931,1.76375921 18.9088652,0.851162839 C16.9189856,-0.617006438 14.1731599,0.257994777 14.1508478,0.265892371 C13.7563845,0.392580224 13.4913708,0.754042012 13.4913708,1.1653696 L13.4913708,6.70673937 C13.4913708,8.45896096 12.6541122,9.94932182 11.0026878,11.1365064 C9.9670917,11.8825354 8.91087479,12.2878582 8.37343166,12.4630412 L8.2842481,12.4864076 C7.95353388,11.9998244 7.41609075,11.7129003 6.82374541,11.7129003 L1.76936011,11.7129003 C0.793740148,11.7129003 0,12.5093172 0,13.4882272 L0,28.3958173 C0,29.3747273 0.793740148,30.171079 1.76936011,30.171079 L6.83675541,30.171079 C7.30374939,30.171079 7.74628457,29.9881289 8.07595799,29.6639359 C8.93546369,30.5150486 10.0956956,31 11.2861757,31 L24.8035665,31 C27.880887,31 29.8459826,29.3777297 30.1941302,26.5549599 L31.9441705,15.6604572 C32.1942878,14.0326391 31.592315,12.3748623 30.3731478,11.3340768 Z" fill="#CBCBCB" fill-rule="nonzero" id="s-Image_17-Fill-1" style="fill:#CBCBCB !important;" />\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_33" class="pie image firer ie-background commentable non-processed" customid="Image_33"   datasizewidth="74.0px" datasizeheight="71.7px" dataX="1129.0" dataY="632.9"   alt="image" systemName="./images/c7ae9432-e39e-405d-b0fc-7636aa9c7ae8.svg" overlay="#CBCBCB">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="31px" version="1.1" viewBox="0 0 32 31" width="32px">\
          	    <!-- Generator: Sketch 55.1 (78136) - https://sketchapp.com -->\
          	    <title>Dislike1</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_33-Page-1" stroke="none" stroke-width="1">\
          	        <g fill="#CBCBCB" fill-rule="nonzero" id="s-Image_33-Dislike1" transform="translate(16.000000, 15.500000) scale(-1, 1) translate(-16.000000, -15.500000) ">\
          	            <path d="M6.71966541,13.6057121 L6.71966541,28.2326439 L6.71316041,28.2326439 L6.71316041,28.2782671 L1.88645011,28.2782671 L1.88645011,13.6057121 L6.71966541,13.6057121 Z M19.8338113,12.1240973 L27.4511017,12.1240973 C28.0625067,12.1240973 28.6646745,12.3534539 29.1472155,12.7702641 C29.8749299,13.3951531 30.2278912,14.3879003 30.0683235,15.3611319 L28.3248533,26.2747585 L28.3175027,26.3132021 C28.2030797,27.2411368 27.8516796,27.9464377 27.273255,28.4093933 C26.689236,28.8767873 25.8561406,29.1137804 24.7970615,29.1137804 L11.2796707,29.1137804 C9.9756783,29.1137804 8.83938484,28.1376116 8.63701427,26.8454739 C8.63018402,26.7971093 8.61801967,26.750768 8.60611552,26.708604 L8.60611552,14.3555919 L8.80744528,14.3089896 C8.81707268,14.3077495 8.82546414,14.3059219 8.83248954,14.3040944 L8.86781169,14.2952178 C9.14577035,14.21337 10.6064031,13.7519808 12.0698331,12.7075403 C14.2382099,11.1639196 15.3843259,9.08887567 15.3843259,6.70673937 L15.3843259,1.93248054 C16.0132294,1.84612916 17.0481099,1.8196298 17.7987219,2.38016317 C18.5231838,2.91608999 18.8905862,3.94793351 18.8905862,5.44704047 L18.8905862,11.1776914 C18.8905862,11.6995201 19.3136714,12.1240973 19.8338113,12.1240973 Z M30.3731478,11.3340768 C29.5477283,10.627079 28.5100507,10.2378124 27.4511017,10.2378124 L20.7770363,10.2378124 L20.7770363,5.44704047 C20.7770363,3.31005593 20.1483931,1.76375921 18.9088652,0.851162839 C16.9189856,-0.617006438 14.1731599,0.257994777 14.1508478,0.265892371 C13.7563845,0.392580224 13.4913708,0.754042012 13.4913708,1.1653696 L13.4913708,6.70673937 C13.4913708,8.45896096 12.6541122,9.94932182 11.0026878,11.1365064 C9.9670917,11.8825354 8.91087479,12.2878582 8.37343166,12.4630412 L8.2842481,12.4864076 C7.95353388,11.9998244 7.41609075,11.7129003 6.82374541,11.7129003 L1.76936011,11.7129003 C0.793740148,11.7129003 0,12.5093172 0,13.4882272 L0,28.3958173 C0,29.3747273 0.793740148,30.171079 1.76936011,30.171079 L6.83675541,30.171079 C7.30374939,30.171079 7.74628457,29.9881289 8.07595799,29.6639359 C8.93546369,30.5150486 10.0956956,31 11.2861757,31 L24.8035665,31 C27.880887,31 29.8459826,29.3777297 30.1941302,26.5549599 L31.9441705,15.6604572 C32.1942878,14.0326391 31.592315,12.3748623 30.3731478,11.3340768 Z" id="s-Image_33-Fill-1" transform="translate(16.000000, 15.500000) scale(-1, 1) rotate(-180.000000) translate(-16.000000, -15.500000) " style="fill:#CBCBCB !important;" />\
          	        </g>\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Input_1" class="checkbox firer commentable non-processed unchecked" customid="Input 1"  datasizewidth="97.5px" datasizeheight="97.5px" dataX="72.2" dataY="621.2"      tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Paragraph_7" class="pie richtext autofit firer ie-background commentable non-processed" customid="Rate the system"   datasizewidth="187.9px" datasizeheight="29.0px" dataX="27.0" dataY="571.8" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">Rate the system</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_4" class="checkbox firer commentable non-processed unchecked" customid="Input 1"  datasizewidth="97.5px" datasizeheight="97.5px" dataX="1118.0" dataY="620.0"      tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Input_6" class="checkbox firer commentable non-processed unchecked" customid="Input 1"  datasizewidth="97.5px" datasizeheight="97.5px" dataX="478.0" dataY="621.2"      tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Input_7" class="checkbox firer commentable non-processed unchecked" customid="Input 1"  datasizewidth="97.5px" datasizeheight="97.5px" dataX="591.2" dataY="621.2"      tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Input_8" class="checkbox firer commentable non-processed unchecked" customid="Input 1"  datasizewidth="97.5px" datasizeheight="97.5px" dataX="704.0" dataY="621.2"      tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Input_9" class="checkbox firer commentable non-processed unchecked" customid="Input 1"  datasizewidth="97.5px" datasizeheight="97.5px" dataX="817.0" dataY="621.2"      tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="pie button multiline manualfit firer click ie-background commentable non-processed" customid="Submit"   datasizewidth="68.0px" datasizeheight="29.0px" dataX="1185.0" dataY="305.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Submit</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="pie button multiline manualfit firer click ie-background commentable non-processed" customid="Submit"   datasizewidth="68.0px" datasizeheight="29.0px" dataX="1185.0" dataY="557.3" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Submit</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_9" class="group firer ie-background commentable non-processed" customid="Header" datasizewidth="1024.0px" datasizeheight="70.0px" >\
        <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_1"   datasizewidth="1281.0px" datasizeheight="70.0px" datasizewidthpx="1280.9999999999998" datasizeheightpx="70.00000000000003" dataX="0.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_37" class="pie image firer ie-background commentable non-processed" customid="Image_37"   datasizewidth="36.0px" datasizeheight="36.0px" dataX="905.0" dataY="17.0"   alt="image" systemName="./images/802a1bc6-8cfd-4443-a195-3efde930d8a7.svg" overlay="#CBCBCB">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 19 20" width="19px">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>Icon</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs />\
            	    <g fill="none" fill-rule="evenodd" id="s-Image_37-Page-1" stroke="none" stroke-width="1">\
            	        <g fill="#B1B1B1" id="Header-#6" transform="translate(-1068.000000, -25.000000)">\
            	            <g id="s-Image_37-Search-" transform="translate(1068.000000, 17.000000)">\
            	                <path d="M12.939,16.271 C12.939,19.121 10.621,21.439 7.771,21.439 C4.921,21.439 2.584,19.121 2.584,16.271 C2.584,13.402 4.902,11.084 7.771,11.084 C10.621,11.084 12.939,13.421 12.939,16.271 L12.939,16.271 Z M14.174,20.66 C15.067,19.387 15.542,17.829 15.542,16.271 C15.542,11.977 12.065,8.5 7.771,8.5 C3.477,8.5 0,11.977 0,16.271 C0,20.565 3.477,24.042 7.771,24.042 C9.329,24.042 10.887,23.548 12.179,22.674 L17.005,27.5 L19,25.505 L14.174,20.66 Z" id="s-Image_37-Icon" style="fill:#CBCBCB !important;" />\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_1" class="pie image lockV firer ie-background commentable non-processed" customid="Image_1"   datasizewidth="217.4px" datasizeheight="67.1px" dataX="22.0" dataY="1.0" aspectRatio="0.30851063"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/abaf42c1-0fff-46a0-b927-b9e6464a0d09.png" />\
          	</div>\
          </div>\
        </div>\
\
        <div id="s-Paragraph_1" class="pie richtext manualfit firer mousedown mouseup click ie-background commentable non-processed" customid="CLANS"   datasizewidth="125.1px" datasizeheight="70.0px" dataX="402.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">CLANS</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_3" class="pie richtext manualfit firer mousedown mouseup click ie-background commentable non-processed" customid="RESOURCES"   datasizewidth="125.1px" datasizeheight="70.0px" dataX="578.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_3_0">RESOURCES</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_4" class="pie richtext manualfit firer mousedown mouseup click ie-background commentable non-processed" customid="FEEDBACK"   datasizewidth="125.1px" datasizeheight="70.0px" dataX="754.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_4_0">FEEDBACK</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_35" class="pie image firer click ie-background commentable non-processed" customid="Image_35"   datasizewidth="30.0px" datasizeheight="35.0px" dataX="1173.0" dataY="18.0"   alt="image" systemName="./images/9bbc6c75-5b3b-4407-abca-ce5697e0a911.svg" overlay="#CBCBCB">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 17 20" width="17px">\
            	    <!-- Generator: Sketch 52.1 (67048) - http://www.bohemiancoding.com/sketch -->\
            	    <title>user</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <g fill="none" fill-rule="evenodd" id="s-Image_35-Page-1" stroke="none" stroke-width="1">\
            	        <g fill="#666666" id="s-Image_35-user">\
            	            <path d="M8.63492063,0 C5.80790159,0 3.50793651,2.29996508 3.50793651,5.12698413 C3.50793651,7.95400317 5.80790159,10.2539683 8.63492063,10.2539683 C11.4619397,10.2539683 13.7619048,7.95400317 13.7619048,5.12698413 C13.7619048,2.29996508 11.4619397,0 8.63492063,0" id="s-Image_35-Fill-1" style="fill:#CBCBCB !important;" />\
            	            <path d="M9.63332578,11.4682653 L7.36665911,11.4682653 C5.40191244,11.4682653 3.55087689,12.2442836 2.15461022,13.65341 C0.765181333,15.0556274 -7.55555556e-06,16.9065514 -7.55555556e-06,18.8653527 C-7.55555556e-06,19.1764059 0.253708,19.4285827 0.566659111,19.4285827 L16.4333258,19.4285827 C16.7462769,19.4285827 16.9999924,19.1764059 16.9999924,18.8653527 C16.9999924,16.9065514 16.2348036,15.0556274 14.8453747,13.65341 C13.449108,12.2442836 11.5981102,11.4682653 9.63332578,11.4682653 Z" id="s-Image_35-Fill-3" style="fill:#CBCBCB !important;" />\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Input" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="214.0px" datasizeheight="29.0px" dataX="952.0" dataY="22.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Search"/></div></div>  </div></div></div>\
      </div>\
\
      <div id="s-Input_10" class="checkbox firer commentable non-processed unchecked" customid="Input 1"  datasizewidth="97.5px" datasizeheight="97.5px" dataX="360.0" dataY="621.2"      tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;