var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1636654481007.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1636654481007-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-537f7d7f-7774-4f4f-a529-e5512ecd7527" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Resources" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/537f7d7f-7774-4f4f-a529-e5512ecd7527-1636654481007.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/537f7d7f-7774-4f4f-a529-e5512ecd7527-1636654481007-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/537f7d7f-7774-4f4f-a529-e5512ecd7527-1636654481007-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Blog-3_13" class="group firer ie-background commentable non-processed" customid="Blog-3" datasizewidth="900.0px" datasizeheight="810.0px" >\
        <div id="s-Bg" class="pie rectangle manualfit firer commentable non-processed" customid="Bg"   datasizewidth="1281.0px" datasizeheight="670.3px" datasizewidthpx="1281.0000000000005" datasizeheightpx="670.2893159360676" dataX="-1.0" dataY="129.8" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Bg_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Bg_1" class="pie rectangle manualfit firer commentable non-processed" customid="Bg_1"   datasizewidth="555.1px" datasizeheight="165.5px" datasizewidthpx="555.0999999999997" datasizeheightpx="165.50353479902958" dataX="51.7" dataY="169.8" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Bg_1_0">Resource Thumbnail</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_8" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Resource creator - Date"   datasizewidth="375.8px" datasizeheight="34.3px" dataX="662.3" dataY="168.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_8_0">Resource creator - Date</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_9" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Resource preview..."   datasizewidth="572.2px" datasizeheight="159.7px" dataX="662.3" dataY="237.5" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_9_0">Resource preview...</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_10" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Resource 1"   datasizewidth="572.2px" datasizeheight="66.6px" dataX="662.3" dataY="185.4" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_10_0">Resource 1</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Bg_2" class="pie rectangle manualfit firer commentable non-processed" customid="Bg_2"   datasizewidth="555.1px" datasizeheight="165.5px" datasizewidthpx="555.0999999999997" datasizeheightpx="165.50353479902975" dataX="51.7" dataY="381.6" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Bg_2_0">Resource Thumbnail</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_11" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Resource Creator - Date"   datasizewidth="375.8px" datasizeheight="34.3px" dataX="662.3" dataY="379.8" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_11_0">Resource Creator - Date</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_12" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Resource preview..."   datasizewidth="572.2px" datasizeheight="147.5px" dataX="662.3" dataY="449.3" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_12_0">Resource preview...</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_13" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Resource 2"   datasizewidth="572.2px" datasizeheight="68.6px" dataX="662.3" dataY="397.2" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_13_0">Resource 2</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Bg_3" class="pie rectangle manualfit firer commentable non-processed" customid="Bg_3"   datasizewidth="555.1px" datasizeheight="165.5px" datasizewidthpx="555.0999999999997" datasizeheightpx="165.503534799029" dataX="51.7" dataY="598.5" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Bg_3_0">Resource Thubmnail</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_14" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Resource creator - Date"   datasizewidth="375.8px" datasizeheight="34.3px" dataX="662.3" dataY="596.8" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_14_0">Resource creator - Date</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_15" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Resource preview..."   datasizewidth="572.2px" datasizeheight="133.7px" dataX="662.3" dataY="666.2" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_15_0">Resource preview...</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_16" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Resource 3"   datasizewidth="572.2px" datasizeheight="66.6px" dataX="662.3" dataY="614.2" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_16_0">Resource 3</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Input" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="214.0px" datasizeheight="29.0px" dataX="53.0" dataY="84.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Search"/></div></div>  </div></div></div>\
      <div id="s-Button_1" class="pie button multiline manualfit firer ie-background commentable non-processed" customid="Search"   datasizewidth="68.0px" datasizeheight="29.0px" dataX="300.0" dataY="84.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Search</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_9" class="group firer ie-background commentable non-processed" customid="Header" datasizewidth="1024.0px" datasizeheight="70.0px" >\
        <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_1"   datasizewidth="1281.0px" datasizeheight="70.0px" datasizewidthpx="1280.9999999999998" datasizeheightpx="70.00000000000003" dataX="0.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_37" class="pie image firer ie-background commentable non-processed" customid="Image_37"   datasizewidth="36.0px" datasizeheight="36.0px" dataX="905.0" dataY="17.0"   alt="image" systemName="./images/1a250b2f-5b4d-4994-ab47-9544c453739e.svg" overlay="#CBCBCB">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 19 20" width="19px">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>Icon</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs />\
            	    <g fill="none" fill-rule="evenodd" id="s-Image_37-Page-1" stroke="none" stroke-width="1">\
            	        <g fill="#B1B1B1" id="Header-#6" transform="translate(-1068.000000, -25.000000)">\
            	            <g id="s-Image_37-Search-" transform="translate(1068.000000, 17.000000)">\
            	                <path d="M12.939,16.271 C12.939,19.121 10.621,21.439 7.771,21.439 C4.921,21.439 2.584,19.121 2.584,16.271 C2.584,13.402 4.902,11.084 7.771,11.084 C10.621,11.084 12.939,13.421 12.939,16.271 L12.939,16.271 Z M14.174,20.66 C15.067,19.387 15.542,17.829 15.542,16.271 C15.542,11.977 12.065,8.5 7.771,8.5 C3.477,8.5 0,11.977 0,16.271 C0,20.565 3.477,24.042 7.771,24.042 C9.329,24.042 10.887,23.548 12.179,22.674 L17.005,27.5 L19,25.505 L14.174,20.66 Z" id="s-Image_37-Icon" style="fill:#CBCBCB !important;" />\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_1" class="pie image lockV firer click ie-background commentable non-processed" customid="Image_1"   datasizewidth="217.4px" datasizeheight="67.1px" dataX="22.0" dataY="1.0" aspectRatio="0.30851063"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/abaf42c1-0fff-46a0-b927-b9e6464a0d09.png" />\
          	</div>\
          </div>\
        </div>\
\
        <div id="s-Paragraph_1" class="pie richtext manualfit firer mousedown mouseup click ie-background commentable non-processed" customid="CLANS"   datasizewidth="125.1px" datasizeheight="70.0px" dataX="402.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">CLANS</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_3" class="pie richtext manualfit firer mousedown mouseup click ie-background commentable non-processed" customid="RESOURCES"   datasizewidth="125.1px" datasizeheight="70.0px" dataX="578.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_3_0">RESOURCES</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_4" class="pie richtext manualfit firer mousedown mouseup click ie-background commentable non-processed" customid="FEEDBACK"   datasizewidth="125.1px" datasizeheight="70.0px" dataX="754.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_4_0">FEEDBACK</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_35" class="pie image firer click ie-background commentable non-processed" customid="Image_35"   datasizewidth="30.0px" datasizeheight="35.0px" dataX="1173.0" dataY="18.0"   alt="image" systemName="./images/46787a04-71dd-4c51-b0b0-a8d9c852a91d.svg" overlay="#CBCBCB">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 17 20" width="17px">\
            	    <!-- Generator: Sketch 52.1 (67048) - http://www.bohemiancoding.com/sketch -->\
            	    <title>user</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <g fill="none" fill-rule="evenodd" id="s-Image_35-Page-1" stroke="none" stroke-width="1">\
            	        <g fill="#666666" id="s-Image_35-user">\
            	            <path d="M8.63492063,0 C5.80790159,0 3.50793651,2.29996508 3.50793651,5.12698413 C3.50793651,7.95400317 5.80790159,10.2539683 8.63492063,10.2539683 C11.4619397,10.2539683 13.7619048,7.95400317 13.7619048,5.12698413 C13.7619048,2.29996508 11.4619397,0 8.63492063,0" id="s-Image_35-Fill-1" style="fill:#CBCBCB !important;" />\
            	            <path d="M9.63332578,11.4682653 L7.36665911,11.4682653 C5.40191244,11.4682653 3.55087689,12.2442836 2.15461022,13.65341 C0.765181333,15.0556274 -7.55555556e-06,16.9065514 -7.55555556e-06,18.8653527 C-7.55555556e-06,19.1764059 0.253708,19.4285827 0.566659111,19.4285827 L16.4333258,19.4285827 C16.7462769,19.4285827 16.9999924,19.1764059 16.9999924,18.8653527 C16.9999924,16.9065514 16.2348036,15.0556274 14.8453747,13.65341 C13.449108,12.2442836 11.5981102,11.4682653 9.63332578,11.4682653 Z" id="s-Image_35-Fill-3" style="fill:#CBCBCB !important;" />\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Input_1" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="214.0px" datasizeheight="29.0px" dataX="952.0" dataY="22.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Search"/></div></div>  </div></div></div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;