var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1636654481007.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1636654481007-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-70a4e4b0-cf69-4987-8af2-befcb1441c29" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Account" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/70a4e4b0-cf69-4987-8af2-befcb1441c29-1636654481007.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/70a4e4b0-cf69-4987-8af2-befcb1441c29-1636654481007-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/70a4e4b0-cf69-4987-8af2-befcb1441c29-1636654481007-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Group_10" class="group firer ie-background commentable non-processed" customid="Account Info" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_2" class="pie rectangle manualfit firer commentable non-processed" customid="Account info box"   datasizewidth="427.0px" datasizeheight="327.0px" datasizewidthpx="426.9999999999998" datasizeheightpx="327.0" dataX="810.0" dataY="105.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_2_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_2" class="pie image firer ie-background commentable non-processed" customid="Image_1"  title="Profile Pic" datasizewidth="170.2px" datasizeheight="170.4px" dataX="939.0" dataY="153.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="resources/jim/images/common/cross.svg" />\
          	</div>\
          </div>\
        </div>\
\
        <div id="s-Paragraph_6" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Sample Username"   datasizewidth="195.0px" datasizeheight="34.0px" dataX="926.0" dataY="334.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_6_0">Sample Username</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_2" class="pie richtext manualfit firer ie-background commentable non-processed" customid="First Last"   datasizewidth="417.0px" datasizeheight="48.0px" dataX="811.0" dataY="105.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_2_0"> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;First Last</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_18" class="pie richtext autofit firer ie-background commentable non-processed" customid="Notoriety: current Level"   datasizewidth="161.5px" datasizeheight="19.0px" dataX="943.0" dataY="368.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_18_0">Notoriety: current Level</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_19" class="pie richtext autofit firer ie-background commentable non-processed" customid="Points to level up: point"   datasizewidth="167.7px" datasizeheight="19.0px" dataX="940.0" dataY="387.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_19_0">Points to level up: points</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Category" class="pie checkboxlist firer commentable non-processed" customid="Category"    datasizewidth="497.0px" datasizeheight="535.2px" dataX="51.0" dataY="146.0"  tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="scroll">\
            <div class="paddingLayer">\
              <table class="collapse" style="height: 100%; width: 100%;" summary="">\
                <tbody>\
                  <tr>\
                    <td>\
                        <div class="checkbox unchecked" name="s-Category"   tabindex="-1" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        </div><span class="option">Ping Notifications</span>\
                    </td>\
                  </tr>\
                  <tr>\
                    <td>\
                        <div class="checkbox unchecked" name="s-Category"   tabindex="-1" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        </div><span class="option">Email Notifications</span>\
                    </td>\
                  </tr>\
                  <tr>\
                    <td>\
                        <div class="checkbox unchecked" name="s-Category"   tabindex="-1" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        </div><span class="option">Share Email</span>\
                    </td>\
                  </tr>\
                  <tr>\
                    <td>\
                        <div class="checkbox unchecked" name="s-Category"   tabindex="-1" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        </div><span class="option">Share Location</span>\
                    </td>\
                  </tr>\
                  <tr>\
                    <td>\
                        <div class="checkbox unchecked" name="s-Category"   tabindex="-1" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        </div><span class="option">Share Phone Number</span>\
                    </td>\
                  </tr>\
                  <tr>\
                    <td>\
                        <div class="checkbox unchecked" name="s-Category"   tabindex="-1" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        </div><span class="option">Recieve messages from non friended users</span>\
                    </td>\
                  </tr>\
                  <tr>\
                    <td>\
                        <div class="checkbox unchecked" name="s-Category"   tabindex="-1" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        </div><span class="option">Display Current Status</span>\
                    </td>\
                  </tr>\
                  <tr>\
                    <td>\
                        <div class="checkbox unchecked" name="s-Category"   tabindex="-1" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        </div><span class="option">Display Notoriety Level</span>\
                    </td>\
                  </tr>\
                  <tr>\
                    <td>\
                        <div class="checkbox unchecked" name="s-Category"   tabindex="-1" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        </div><span class="option">Display Clan Information</span>\
                    </td>\
                  </tr>\
                </tbody>\
              </table>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="pie richtext autofit firer ie-background commentable non-processed" customid="Quick Settings"   datasizewidth="232.1px" datasizeheight="41.0px" dataX="51.0" dataY="105.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">Quick Settings</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="pie button multiline manualfit firer ie-background commentable non-processed" customid="Advanced Settings"   datasizewidth="344.0px" datasizeheight="55.2px" dataX="127.5" dataY="703.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Advanced Settings</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="pie button multiline manualfit firer ie-background commentable non-processed" customid="Change Profile Photo"   datasizewidth="344.0px" datasizeheight="55.2px" dataX="852.0" dataY="450.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Change Profile Photo</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_3" class="pie button multiline manualfit firer ie-background commentable non-processed" customid="Change Bio"   datasizewidth="344.0px" datasizeheight="55.2px" dataX="852.0" dataY="526.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_3_0">Change Bio</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_4" class="pie button multiline manualfit firer ie-background commentable non-processed" customid="Change Contact info"   datasizewidth="344.0px" datasizeheight="55.2px" dataX="852.0" dataY="602.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_4_0">Change Contact info</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_9" class="group firer ie-background commentable non-processed" customid="Header" datasizewidth="1024.0px" datasizeheight="70.0px" >\
        <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_1"   datasizewidth="1281.0px" datasizeheight="70.0px" datasizewidthpx="1280.9999999999998" datasizeheightpx="70.00000000000003" dataX="0.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_37" class="pie image firer ie-background commentable non-processed" customid="Image_37"   datasizewidth="36.0px" datasizeheight="36.0px" dataX="905.0" dataY="17.0"   alt="image" systemName="./images/0220920b-9f59-454d-9282-050054363df6.svg" overlay="#CBCBCB">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 19 20" width="19px">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>Icon</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs />\
            	    <g fill="none" fill-rule="evenodd" id="s-Image_37-Page-1" stroke="none" stroke-width="1">\
            	        <g fill="#B1B1B1" id="Header-#6" transform="translate(-1068.000000, -25.000000)">\
            	            <g id="s-Image_37-Search-" transform="translate(1068.000000, 17.000000)">\
            	                <path d="M12.939,16.271 C12.939,19.121 10.621,21.439 7.771,21.439 C4.921,21.439 2.584,19.121 2.584,16.271 C2.584,13.402 4.902,11.084 7.771,11.084 C10.621,11.084 12.939,13.421 12.939,16.271 L12.939,16.271 Z M14.174,20.66 C15.067,19.387 15.542,17.829 15.542,16.271 C15.542,11.977 12.065,8.5 7.771,8.5 C3.477,8.5 0,11.977 0,16.271 C0,20.565 3.477,24.042 7.771,24.042 C9.329,24.042 10.887,23.548 12.179,22.674 L17.005,27.5 L19,25.505 L14.174,20.66 Z" id="s-Image_37-Icon" style="fill:#CBCBCB !important;" />\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_1" class="pie image lockV firer click ie-background commentable non-processed" customid="Image_1"   datasizewidth="217.4px" datasizeheight="67.1px" dataX="22.0" dataY="1.5" aspectRatio="0.30851063"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/abaf42c1-0fff-46a0-b927-b9e6464a0d09.png" />\
          	</div>\
          </div>\
        </div>\
\
        <div id="s-Paragraph_1" class="pie richtext manualfit firer mousedown mouseup click ie-background commentable non-processed" customid="CLANS"   datasizewidth="125.1px" datasizeheight="70.0px" dataX="402.0" dataY="-0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">CLANS</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_3" class="pie richtext manualfit firer mousedown mouseup click ie-background commentable non-processed" customid="RESOURCES"   datasizewidth="125.1px" datasizeheight="70.0px" dataX="578.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_3_0">RESOURCES</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_4" class="pie richtext manualfit firer mousedown mouseup click ie-background commentable non-processed" customid="FEEDBACK"   datasizewidth="125.1px" datasizeheight="70.0px" dataX="754.0" dataY="-0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_4_0">FEEDBACK</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_35" class="pie image firer click ie-background commentable non-processed" customid="Image_35"   datasizewidth="30.0px" datasizeheight="35.0px" dataX="1173.0" dataY="18.0"   alt="image" systemName="./images/2bc01c14-eeb3-43ae-8bbc-8e82fba9983f.svg" overlay="#CBCBCB">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 17 20" width="17px">\
            	    <!-- Generator: Sketch 52.1 (67048) - http://www.bohemiancoding.com/sketch -->\
            	    <title>user</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <g fill="none" fill-rule="evenodd" id="s-Image_35-Page-1" stroke="none" stroke-width="1">\
            	        <g fill="#666666" id="s-Image_35-user">\
            	            <path d="M8.63492063,0 C5.80790159,0 3.50793651,2.29996508 3.50793651,5.12698413 C3.50793651,7.95400317 5.80790159,10.2539683 8.63492063,10.2539683 C11.4619397,10.2539683 13.7619048,7.95400317 13.7619048,5.12698413 C13.7619048,2.29996508 11.4619397,0 8.63492063,0" id="s-Image_35-Fill-1" style="fill:#CBCBCB !important;" />\
            	            <path d="M9.63332578,11.4682653 L7.36665911,11.4682653 C5.40191244,11.4682653 3.55087689,12.2442836 2.15461022,13.65341 C0.765181333,15.0556274 -7.55555556e-06,16.9065514 -7.55555556e-06,18.8653527 C-7.55555556e-06,19.1764059 0.253708,19.4285827 0.566659111,19.4285827 L16.4333258,19.4285827 C16.7462769,19.4285827 16.9999924,19.1764059 16.9999924,18.8653527 C16.9999924,16.9065514 16.2348036,15.0556274 14.8453747,13.65341 C13.449108,12.2442836 11.5981102,11.4682653 9.63332578,11.4682653 Z" id="s-Image_35-Fill-3" style="fill:#CBCBCB !important;" />\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Input" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="214.0px" datasizeheight="29.0px" dataX="952.0" dataY="22.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Search"/></div></div>  </div></div></div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;