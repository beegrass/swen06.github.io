(function(window, undefined) {

  var jimLinks = {
    "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b" : {
      "Image_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_1" : [
        "b30ead33-5801-47a5-aa05-de561a04dad6"
      ],
      "Paragraph_3" : [
        "537f7d7f-7774-4f4f-a529-e5512ecd7527"
      ],
      "Paragraph_4" : [
        "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"
      ],
      "Image_35" : [
        "70a4e4b0-cf69-4987-8af2-befcb1441c29"
      ]
    },
    "537f7d7f-7774-4f4f-a529-e5512ecd7527" : {
      "Image_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_1" : [
        "b30ead33-5801-47a5-aa05-de561a04dad6"
      ],
      "Paragraph_3" : [
        "537f7d7f-7774-4f4f-a529-e5512ecd7527"
      ],
      "Paragraph_4" : [
        "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"
      ],
      "Image_35" : [
        "70a4e4b0-cf69-4987-8af2-befcb1441c29"
      ]
    },
    "70a4e4b0-cf69-4987-8af2-befcb1441c29" : {
      "Image_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_1" : [
        "b30ead33-5801-47a5-aa05-de561a04dad6"
      ],
      "Paragraph_3" : [
        "537f7d7f-7774-4f4f-a529-e5512ecd7527"
      ],
      "Paragraph_4" : [
        "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"
      ],
      "Image_35" : [
        "70a4e4b0-cf69-4987-8af2-befcb1441c29"
      ]
    },
    "b30ead33-5801-47a5-aa05-de561a04dad6" : {
      "Image_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_1" : [
        "b30ead33-5801-47a5-aa05-de561a04dad6"
      ],
      "Paragraph_3" : [
        "537f7d7f-7774-4f4f-a529-e5512ecd7527"
      ],
      "Paragraph_4" : [
        "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"
      ],
      "Image_35" : [
        "70a4e4b0-cf69-4987-8af2-befcb1441c29"
      ]
    },
    "7e40b955-4e01-48f6-ad1d-ff61a395ca3e" : {
      "Rectangle_3" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "ee5f6a9d-589d-41c1-906a-9d216fa3618c" : {
      "Rectangle_3" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_8" : [
        "7e40b955-4e01-48f6-ad1d-ff61a395ca3e"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Paragraph_1" : [
        "b30ead33-5801-47a5-aa05-de561a04dad6"
      ],
      "Paragraph_3" : [
        "537f7d7f-7774-4f4f-a529-e5512ecd7527"
      ],
      "Paragraph_4" : [
        "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"
      ],
      "Image_35" : [
        "70a4e4b0-cf69-4987-8af2-befcb1441c29"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);