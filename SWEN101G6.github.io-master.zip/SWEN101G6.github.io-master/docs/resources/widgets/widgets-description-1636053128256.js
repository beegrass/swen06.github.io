	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Paragraph_2", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_5", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Input_2", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["Input area", "s-Input_2"]; 

	widgets.descriptionMap[["s-Paragraph_6", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["Text", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Input_3", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["Input area", "s-Input_3"]; 

	widgets.descriptionMap[["s-Image_17", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_17", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["Like", "s-Image_17"]; 

	widgets.descriptionMap[["s-Image_33", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_33", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["Dislike", "s-Image_33"]; 

	widgets.descriptionMap[["s-Input_1", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["Check box", "s-Input_1"]; 

	widgets.descriptionMap[["s-Paragraph_7", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["Text", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Input_4", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Input_4", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["Check box", "s-Input_4"]; 

	widgets.descriptionMap[["s-Input_6", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Input_6", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["Check box", "s-Input_6"]; 

	widgets.descriptionMap[["s-Input_7", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Input_7", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["Check box", "s-Input_7"]; 

	widgets.descriptionMap[["s-Input_8", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Input_8", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["Check box", "s-Input_8"]; 

	widgets.descriptionMap[["s-Input_9", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Input_9", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["Check box", "s-Input_9"]; 

	widgets.descriptionMap[["s-Button_1", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button_2", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["Button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Rectangle_1", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["Dark header", "s-Group_9"]; 

	widgets.descriptionMap[["s-Image_37", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_37", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["Search icon", "s-Image_37"]; 

	widgets.descriptionMap[["s-Image_1", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["Logo Acme", "s-Image_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["Dark header", "s-Group_9"]; 

	widgets.descriptionMap[["s-Paragraph_3", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["Dark header", "s-Group_9"]; 

	widgets.descriptionMap[["s-Paragraph_4", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["Dark header", "s-Group_9"]; 

	widgets.descriptionMap[["s-Image_35", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Input", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Input", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["Input Text Field", "s-Input"]; 

	widgets.descriptionMap[["s-Input_10", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ""; 

			widgets.rootWidgetMap[["s-Input_10", "7b2ed56c-0ff9-4871-9e7d-8481477f0e1b"]] = ["Check box", "s-Input_10"]; 

	widgets.descriptionMap[["s-Bg", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ["Blog 3", "s-Blog-3_13"]; 

	widgets.descriptionMap[["s-Bg_1", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_1", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ["Blog 3", "s-Blog-3_13"]; 

	widgets.descriptionMap[["s-Paragraph_8", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ["Paragraph 1", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Paragraph_9", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ["Paragraph 1", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Paragraph_10", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ["Title 1", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Bg_2", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_2", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ["Blog 3", "s-Blog-3_13"]; 

	widgets.descriptionMap[["s-Paragraph_11", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ["Paragraph 1", "s-Paragraph_11"]; 

	widgets.descriptionMap[["s-Paragraph_12", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ["Paragraph 1", "s-Paragraph_12"]; 

	widgets.descriptionMap[["s-Paragraph_13", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ["Title 1", "s-Paragraph_13"]; 

	widgets.descriptionMap[["s-Bg_3", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_3", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ["Blog 3", "s-Blog-3_13"]; 

	widgets.descriptionMap[["s-Paragraph_14", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ["Paragraph 1", "s-Paragraph_14"]; 

	widgets.descriptionMap[["s-Paragraph_15", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_15", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ["Paragraph 1", "s-Paragraph_15"]; 

	widgets.descriptionMap[["s-Paragraph_16", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_16", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ["Title 1", "s-Paragraph_16"]; 

	widgets.descriptionMap[["s-Input", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ""; 

			widgets.rootWidgetMap[["s-Input", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ["Input Text Field", "s-Input"]; 

	widgets.descriptionMap[["s-Button_1", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Rectangle_1", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ["Dark header", "s-Group_9"]; 

	widgets.descriptionMap[["s-Image_37", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ""; 

			widgets.rootWidgetMap[["s-Image_37", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ["Search icon", "s-Image_37"]; 

	widgets.descriptionMap[["s-Image_1", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ["Logo Acme", "s-Image_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ["Dark header", "s-Group_9"]; 

	widgets.descriptionMap[["s-Paragraph_3", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ["Dark header", "s-Group_9"]; 

	widgets.descriptionMap[["s-Paragraph_4", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ["Dark header", "s-Group_9"]; 

	widgets.descriptionMap[["s-Image_35", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Input_1", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "537f7d7f-7774-4f4f-a529-e5512ecd7527"]] = ["Input Text Field", "s-Input_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Image_2", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ["Image placeholder", "s-Image_2"]; 

	widgets.descriptionMap[["s-Paragraph_6", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ["h4", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Paragraph_2", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ["h3", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_18", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_18", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ["Text", "s-Paragraph_18"]; 

	widgets.descriptionMap[["s-Paragraph_19", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_19", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ["Text", "s-Paragraph_19"]; 

	widgets.descriptionMap[["s-Category", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ""; 

			widgets.rootWidgetMap[["s-Category", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ["Check List", "s-Category"]; 

	widgets.descriptionMap[["s-Paragraph_5", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Button_1", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button_2", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ["Button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Button_3", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ["Button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Button_4", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ["Button", "s-Button_4"]; 

	widgets.descriptionMap[["s-Rectangle_1", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ["Dark header", "s-Group_9"]; 

	widgets.descriptionMap[["s-Image_37", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ""; 

			widgets.rootWidgetMap[["s-Image_37", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ["Search icon", "s-Image_37"]; 

	widgets.descriptionMap[["s-Image_1", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ["Logo Acme", "s-Image_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ["Dark header", "s-Group_9"]; 

	widgets.descriptionMap[["s-Paragraph_3", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ["Dark header", "s-Group_9"]; 

	widgets.descriptionMap[["s-Paragraph_4", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ["Dark header", "s-Group_9"]; 

	widgets.descriptionMap[["s-Image_35", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Input", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ""; 

			widgets.rootWidgetMap[["s-Input", "70a4e4b0-cf69-4987-8af2-befcb1441c29"]] = ["Input Text Field", "s-Input"]; 

	widgets.descriptionMap[["s-Rectangle_2", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Image_2", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ["Image placeholder", "s-Image_2"]; 

	widgets.descriptionMap[["s-Paragraph_6", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ["h4", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Paragraph_18", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_18", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ["Text", "s-Paragraph_18"]; 

	widgets.descriptionMap[["s-Paragraph_5", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Rectangle_1", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ["Dark header", "s-Group_9"]; 

	widgets.descriptionMap[["s-Image_37", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_37", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ["Search icon", "s-Image_37"]; 

	widgets.descriptionMap[["s-Image_1", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ["Logo Acme", "s-Image_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ["Dark header", "s-Group_9"]; 

	widgets.descriptionMap[["s-Paragraph_3", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ["Dark header", "s-Group_9"]; 

	widgets.descriptionMap[["s-Paragraph_4", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ["Dark header", "s-Group_9"]; 

	widgets.descriptionMap[["s-Image_35", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Input", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ""; 

			widgets.rootWidgetMap[["s-Input", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ["Input Text Field", "s-Input"]; 

	widgets.descriptionMap[["s-Rectangle_3", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ["Rectangle", "s-Rectangle_3"]; 

	widgets.descriptionMap[["s-Image_3", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ["Image placeholder", "s-Image_3"]; 

	widgets.descriptionMap[["s-Paragraph_7", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ["h4", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Paragraph_19", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_19", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ["Text", "s-Paragraph_19"]; 

	widgets.descriptionMap[["s-Paragraph_8", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ["Text", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Rectangle_4", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ["Rectangle", "s-Rectangle_4"]; 

	widgets.descriptionMap[["s-Paragraph_25", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_25", "b30ead33-5801-47a5-aa05-de561a04dad6"]] = ["h2", "s-Paragraph_25"]; 

	widgets.descriptionMap[["s-Rectangle_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Dark header", "s-Group_9"]; 

	widgets.descriptionMap[["s-Image_37", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_37", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Search icon", "s-Image_37"]; 

	widgets.descriptionMap[["s-Image_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Logo Acme", "s-Image_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Dark header", "s-Group_9"]; 

	widgets.descriptionMap[["s-Paragraph_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Dark header", "s-Group_9"]; 

	widgets.descriptionMap[["s-Paragraph_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Dark header", "s-Group_9"]; 

	widgets.descriptionMap[["s-Image_35", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Input", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Input", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Input Text Field", "s-Input"]; 

	widgets.descriptionMap[["s-Rectangle_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Image_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Image placeholder", "s-Image_2"]; 

	widgets.descriptionMap[["s-Paragraph_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["h4", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Paragraph_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["h3", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_18", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_18", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Text", "s-Paragraph_18"]; 

	widgets.descriptionMap[["s-Paragraph_19", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_19", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Text", "s-Paragraph_19"]; 

	widgets.descriptionMap[["s-Rectangle_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Rectangle", "s-Rectangle_3"]; 

	widgets.descriptionMap[["s-Paragraph_25", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_25", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["h2", "s-Paragraph_25"]; 

	widgets.descriptionMap[["s-Rectangle_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Rectangle", "s-Rectangle_4"]; 

	widgets.descriptionMap[["s-Paragraph_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["h2", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Rectangle_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Rectangle", "s-Rectangle_5"]; 

	widgets.descriptionMap[["s-Bg", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Blog 3", "s-Blog-3_13"]; 

	widgets.descriptionMap[["s-Bg_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Blog 3", "s-Blog-3_13"]; 

	widgets.descriptionMap[["s-Paragraph_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Paragraph 1", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Paragraph_9", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Paragraph 1", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Paragraph_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Title 1", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Bg_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Blog 3", "s-Blog-3_13"]; 

	widgets.descriptionMap[["s-Paragraph_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Paragraph 1", "s-Paragraph_11"]; 

	widgets.descriptionMap[["s-Paragraph_12", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Paragraph 1", "s-Paragraph_12"]; 

	widgets.descriptionMap[["s-Paragraph_13", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Title 1", "s-Paragraph_13"]; 

	widgets.descriptionMap[["s-Bg_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Blog 3", "s-Blog-3_13"]; 

	widgets.descriptionMap[["s-Paragraph_14", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Paragraph 1", "s-Paragraph_14"]; 

	widgets.descriptionMap[["s-Paragraph_15", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_15", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Paragraph 1", "s-Paragraph_15"]; 

	widgets.descriptionMap[["s-Paragraph_16", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_16", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Title 1", "s-Paragraph_16"]; 

	widgets.descriptionMap[["s-Paragraph_17", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_17", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["h2", "s-Paragraph_17"]; 

	